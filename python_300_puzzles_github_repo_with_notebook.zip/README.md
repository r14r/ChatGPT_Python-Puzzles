# 🧠 300 Advanced Python Coding Puzzles

This repository contains **300 Python coding puzzles** with full solutions, tests, and a PDF/Markdown reference.

## 📁 Structure
- `code/`: Python source files for each puzzle
- `tests/`: Pytest unit tests
- `docs/`: Markdown and PDF documentation

## 🚀 Run Tests

```bash
pip install pytest
pytest tests/
```
