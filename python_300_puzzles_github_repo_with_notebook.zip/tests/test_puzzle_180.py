# Test for 180. Puzzle 180
from code.puzzle_180 import solution

def test_solution():
    assert callable(solution)
