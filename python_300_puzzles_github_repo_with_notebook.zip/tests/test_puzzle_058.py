# Auto-generated test for 58. Puzzle 58
from code.puzzle_058 import solution

def test_solution():
    assert callable(solution)
