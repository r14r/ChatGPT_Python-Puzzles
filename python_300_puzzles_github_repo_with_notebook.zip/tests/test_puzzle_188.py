# Test for 188. Puzzle 188
from code.puzzle_188 import solution

def test_solution():
    assert callable(solution)
