# Test for 195. Puzzle 195
from code.puzzle_195 import solution

def test_solution():
    assert callable(solution)
