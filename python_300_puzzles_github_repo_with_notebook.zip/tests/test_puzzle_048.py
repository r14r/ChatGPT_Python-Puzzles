# Auto-generated test for 48. Puzzle 48
from code.puzzle_048 import solution

def test_solution():
    assert callable(solution)
