# Auto-generated test for 75. Puzzle 75
from code.puzzle_075 import solution

def test_solution():
    assert callable(solution)
