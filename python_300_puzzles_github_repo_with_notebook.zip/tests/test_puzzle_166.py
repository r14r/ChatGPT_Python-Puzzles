# Test for 166. Puzzle 166
from code.puzzle_166 import solution

def test_solution():
    assert callable(solution)
