# Auto-generated test for 11. Puzzle 11
from code.puzzle_011 import solution

def test_solution():
    assert callable(solution)
