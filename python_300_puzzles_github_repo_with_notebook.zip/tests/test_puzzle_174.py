# Test for 174. Puzzle 174
from code.puzzle_174 import solution

def test_solution():
    assert callable(solution)
