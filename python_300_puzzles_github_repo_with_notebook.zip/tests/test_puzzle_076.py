# Auto-generated test for 76. Puzzle 76
from code.puzzle_076 import solution

def test_solution():
    assert callable(solution)
