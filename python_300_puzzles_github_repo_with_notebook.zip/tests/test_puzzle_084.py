# Auto-generated test for 84. Puzzle 84
from code.puzzle_084 import solution

def test_solution():
    assert callable(solution)
