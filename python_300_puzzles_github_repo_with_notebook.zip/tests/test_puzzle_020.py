# Auto-generated test for 20. Puzzle 20
from code.puzzle_020 import solution

def test_solution():
    assert callable(solution)
