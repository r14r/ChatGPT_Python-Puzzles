# Test for 155. Puzzle 155
from code.puzzle_155 import solution

def test_solution():
    assert callable(solution)
