# Auto-generated test for 4. Puzzle 4
from code.puzzle_004 import flatten

def test_flatten():
    assert callable(flatten)
