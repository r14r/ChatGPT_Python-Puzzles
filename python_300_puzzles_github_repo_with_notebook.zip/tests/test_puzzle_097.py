# Auto-generated test for 97. Puzzle 97
from code.puzzle_097 import solution

def test_solution():
    assert callable(solution)
