# Test for 117. Puzzle 117
from code.puzzle_117 import solution

def test_solution():
    assert callable(solution)
