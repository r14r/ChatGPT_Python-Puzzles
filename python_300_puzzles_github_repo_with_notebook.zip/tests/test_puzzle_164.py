# Test for 164. Puzzle 164
from code.puzzle_164 import solution

def test_solution():
    assert callable(solution)
