# Test for 148. Puzzle 148
from code.puzzle_148 import solution

def test_solution():
    assert callable(solution)
