# Auto-generated test for 81. Puzzle 81
from code.puzzle_081 import solution

def test_solution():
    assert callable(solution)
