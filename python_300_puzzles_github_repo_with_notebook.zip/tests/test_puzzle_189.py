# Test for 189. Puzzle 189
from code.puzzle_189 import solution

def test_solution():
    assert callable(solution)
