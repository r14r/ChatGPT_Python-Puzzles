# Test for 121. Puzzle 121
from code.puzzle_121 import solution

def test_solution():
    assert callable(solution)
