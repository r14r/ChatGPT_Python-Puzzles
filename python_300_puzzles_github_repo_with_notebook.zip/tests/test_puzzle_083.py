# Auto-generated test for 83. Puzzle 83
from code.puzzle_083 import solution

def test_solution():
    assert callable(solution)
