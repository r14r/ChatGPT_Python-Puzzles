# Test for 158. Puzzle 158
from code.puzzle_158 import solution

def test_solution():
    assert callable(solution)
