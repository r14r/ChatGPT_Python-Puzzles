# Test for 122. Puzzle 122
from code.puzzle_122 import solution

def test_solution():
    assert callable(solution)
