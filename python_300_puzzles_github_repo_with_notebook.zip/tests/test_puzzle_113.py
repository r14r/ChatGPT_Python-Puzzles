# Test for 113. Puzzle 113
from code.puzzle_113 import solution

def test_solution():
    assert callable(solution)
