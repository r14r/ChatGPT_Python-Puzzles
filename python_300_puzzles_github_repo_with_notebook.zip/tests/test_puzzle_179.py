# Test for 179. Puzzle 179
from code.puzzle_179 import solution

def test_solution():
    assert callable(solution)
