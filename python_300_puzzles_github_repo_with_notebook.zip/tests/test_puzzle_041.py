# Auto-generated test for 41. Puzzle 41
from code.puzzle_041 import solution

def test_solution():
    assert callable(solution)
