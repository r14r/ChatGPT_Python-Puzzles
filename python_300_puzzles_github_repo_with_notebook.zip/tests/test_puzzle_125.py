# Test for 125. Puzzle 125
from code.puzzle_125 import solution

def test_solution():
    assert callable(solution)
