# Test for 110. Puzzle 110
from code.puzzle_110 import solution

def test_solution():
    assert callable(solution)
