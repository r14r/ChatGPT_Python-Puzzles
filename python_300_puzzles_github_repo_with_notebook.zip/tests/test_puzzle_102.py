# Test for 102. Puzzle 102
from code.puzzle_102 import solution

def test_solution():
    assert callable(solution)
