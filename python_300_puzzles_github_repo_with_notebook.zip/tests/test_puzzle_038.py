# Auto-generated test for 38. Puzzle 38
from code.puzzle_038 import solution

def test_solution():
    assert callable(solution)
