# Test for 172. Puzzle 172
from code.puzzle_172 import solution

def test_solution():
    assert callable(solution)
