# Auto-generated test for 86. Puzzle 86
from code.puzzle_086 import solution

def test_solution():
    assert callable(solution)
