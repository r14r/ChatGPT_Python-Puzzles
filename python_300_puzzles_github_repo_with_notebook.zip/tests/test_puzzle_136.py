# Test for 136. Puzzle 136
from code.puzzle_136 import solution

def test_solution():
    assert callable(solution)
