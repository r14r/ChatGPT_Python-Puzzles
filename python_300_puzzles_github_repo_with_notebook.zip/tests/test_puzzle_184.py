# Test for 184. Puzzle 184
from code.puzzle_184 import solution

def test_solution():
    assert callable(solution)
