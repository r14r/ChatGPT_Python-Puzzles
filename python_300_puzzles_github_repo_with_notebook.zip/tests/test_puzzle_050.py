# Auto-generated test for 50. Puzzle 50
from code.puzzle_050 import solution

def test_solution():
    assert callable(solution)
