# Test for 182. Puzzle 182
from code.puzzle_182 import solution

def test_solution():
    assert callable(solution)
