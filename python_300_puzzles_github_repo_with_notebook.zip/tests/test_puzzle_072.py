# Auto-generated test for 72. Puzzle 72
from code.puzzle_072 import solution

def test_solution():
    assert callable(solution)
