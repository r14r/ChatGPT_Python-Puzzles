# Auto-generated test for 62. Puzzle 62
from code.puzzle_062 import solution

def test_solution():
    assert callable(solution)
