# Auto-generated test for 56. Puzzle 56
from code.puzzle_056 import solution

def test_solution():
    assert callable(solution)
