# Auto-generated test for 1. Puzzle 1
from code.puzzle_001 import binary_search

def test_binary_search():
    assert callable(binary_search)
