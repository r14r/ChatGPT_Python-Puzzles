# Test for 131. Puzzle 131
from code.puzzle_131 import solution

def test_solution():
    assert callable(solution)
