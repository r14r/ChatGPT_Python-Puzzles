# Auto-generated test for 87. Puzzle 87
from code.puzzle_087 import solution

def test_solution():
    assert callable(solution)
