# Test for 124. Puzzle 124
from code.puzzle_124 import solution

def test_solution():
    assert callable(solution)
