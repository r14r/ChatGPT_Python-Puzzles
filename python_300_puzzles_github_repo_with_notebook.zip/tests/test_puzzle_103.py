# Test for 103. Puzzle 103
from code.puzzle_103 import solution

def test_solution():
    assert callable(solution)
