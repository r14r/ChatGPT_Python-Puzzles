# Auto-generated test for 3. Puzzle 3
from code.puzzle_003 import __init__

def test___init__():
    assert callable(__init__)
