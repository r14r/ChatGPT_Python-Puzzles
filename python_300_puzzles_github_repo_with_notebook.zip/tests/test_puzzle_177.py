# Test for 177. Puzzle 177
from code.puzzle_177 import solution

def test_solution():
    assert callable(solution)
