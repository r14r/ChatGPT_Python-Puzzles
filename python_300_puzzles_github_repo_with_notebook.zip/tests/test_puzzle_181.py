# Test for 181. Puzzle 181
from code.puzzle_181 import solution

def test_solution():
    assert callable(solution)
