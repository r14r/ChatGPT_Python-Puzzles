# Test for 123. Puzzle 123
from code.puzzle_123 import solution

def test_solution():
    assert callable(solution)
