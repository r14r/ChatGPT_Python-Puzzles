# Test for 163. Puzzle 163
from code.puzzle_163 import solution

def test_solution():
    assert callable(solution)
