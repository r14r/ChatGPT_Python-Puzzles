# Auto-generated test for 70. Puzzle 70
from code.puzzle_070 import solution

def test_solution():
    assert callable(solution)
