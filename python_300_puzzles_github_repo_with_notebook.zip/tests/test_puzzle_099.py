# Auto-generated test for 99. Puzzle 99
from code.puzzle_099 import solution

def test_solution():
    assert callable(solution)
