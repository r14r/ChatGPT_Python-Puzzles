# Auto-generated test for 67. Puzzle 67
from code.puzzle_067 import solution

def test_solution():
    assert callable(solution)
