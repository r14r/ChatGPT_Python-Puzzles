# Test for 160. Puzzle 160
from code.puzzle_160 import solution

def test_solution():
    assert callable(solution)
