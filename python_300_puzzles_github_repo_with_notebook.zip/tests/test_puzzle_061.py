# Auto-generated test for 61. Puzzle 61
from code.puzzle_061 import solution

def test_solution():
    assert callable(solution)
