# Test for 134. Puzzle 134
from code.puzzle_134 import solution

def test_solution():
    assert callable(solution)
