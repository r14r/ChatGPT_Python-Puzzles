# Auto-generated test for 15. Puzzle 15
from code.puzzle_015 import solution

def test_solution():
    assert callable(solution)
