# Auto-generated test for 82. Puzzle 82
from code.puzzle_082 import solution

def test_solution():
    assert callable(solution)
