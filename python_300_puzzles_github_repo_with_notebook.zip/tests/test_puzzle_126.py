# Test for 126. Puzzle 126
from code.puzzle_126 import solution

def test_solution():
    assert callable(solution)
