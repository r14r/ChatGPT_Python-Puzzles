# Auto-generated test for 40. Puzzle 40
from code.puzzle_040 import solution

def test_solution():
    assert callable(solution)
