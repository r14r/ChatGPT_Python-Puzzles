# Auto-generated test for 18. Puzzle 18
from code.puzzle_018 import solution

def test_solution():
    assert callable(solution)
