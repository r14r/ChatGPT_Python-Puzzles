# Auto-generated test for 93. Puzzle 93
from code.puzzle_093 import solution

def test_solution():
    assert callable(solution)
