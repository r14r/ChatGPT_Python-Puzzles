# Test for 197. Puzzle 197
from code.puzzle_197 import solution

def test_solution():
    assert callable(solution)
