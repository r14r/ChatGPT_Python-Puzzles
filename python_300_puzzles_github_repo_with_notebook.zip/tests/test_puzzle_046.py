# Auto-generated test for 46. Puzzle 46
from code.puzzle_046 import solution

def test_solution():
    assert callable(solution)
