# Test for 145. Puzzle 145
from code.puzzle_145 import solution

def test_solution():
    assert callable(solution)
