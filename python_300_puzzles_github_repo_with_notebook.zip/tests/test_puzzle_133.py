# Test for 133. Puzzle 133
from code.puzzle_133 import solution

def test_solution():
    assert callable(solution)
