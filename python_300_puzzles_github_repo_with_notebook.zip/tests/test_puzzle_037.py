# Auto-generated test for 37. Puzzle 37
from code.puzzle_037 import solution

def test_solution():
    assert callable(solution)
