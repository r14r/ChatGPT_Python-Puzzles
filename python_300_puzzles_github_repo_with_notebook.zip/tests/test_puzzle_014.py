# Auto-generated test for 14. Puzzle 14
from code.puzzle_014 import solution

def test_solution():
    assert callable(solution)
