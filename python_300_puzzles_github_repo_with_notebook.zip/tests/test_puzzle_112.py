# Test for 112. Puzzle 112
from code.puzzle_112 import solution

def test_solution():
    assert callable(solution)
