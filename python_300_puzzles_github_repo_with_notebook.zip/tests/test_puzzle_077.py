# Auto-generated test for 77. Puzzle 77
from code.puzzle_077 import solution

def test_solution():
    assert callable(solution)
