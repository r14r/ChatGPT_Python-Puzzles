# Auto-generated test for 78. Puzzle 78
from code.puzzle_078 import solution

def test_solution():
    assert callable(solution)
