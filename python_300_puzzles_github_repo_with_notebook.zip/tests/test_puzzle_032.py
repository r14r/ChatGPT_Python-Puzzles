# Auto-generated test for 32. Puzzle 32
from code.puzzle_032 import solution

def test_solution():
    assert callable(solution)
