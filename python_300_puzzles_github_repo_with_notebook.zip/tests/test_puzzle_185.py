# Test for 185. Puzzle 185
from code.puzzle_185 import solution

def test_solution():
    assert callable(solution)
