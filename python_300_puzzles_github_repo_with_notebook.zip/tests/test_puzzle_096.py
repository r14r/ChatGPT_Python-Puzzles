# Auto-generated test for 96. Puzzle 96
from code.puzzle_096 import solution

def test_solution():
    assert callable(solution)
