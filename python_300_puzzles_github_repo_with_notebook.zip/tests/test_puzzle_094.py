# Auto-generated test for 94. Puzzle 94
from code.puzzle_094 import solution

def test_solution():
    assert callable(solution)
