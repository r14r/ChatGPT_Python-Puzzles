# Test for 151. Puzzle 151
from code.puzzle_151 import solution

def test_solution():
    assert callable(solution)
