# Auto-generated test for 6. Puzzle 6
from code.puzzle_006 import longest_unique_substring

def test_longest_unique_substring():
    assert callable(longest_unique_substring)
