# Test for 161. Puzzle 161
from code.puzzle_161 import solution

def test_solution():
    assert callable(solution)
