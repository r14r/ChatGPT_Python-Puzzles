# Test for 128. Puzzle 128
from code.puzzle_128 import solution

def test_solution():
    assert callable(solution)
