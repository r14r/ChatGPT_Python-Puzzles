# Test for 150. Puzzle 150
from code.puzzle_150 import solution

def test_solution():
    assert callable(solution)
