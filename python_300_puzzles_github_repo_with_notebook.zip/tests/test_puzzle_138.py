# Test for 138. Puzzle 138
from code.puzzle_138 import solution

def test_solution():
    assert callable(solution)
