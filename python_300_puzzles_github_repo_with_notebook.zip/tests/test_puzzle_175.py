# Test for 175. Puzzle 175
from code.puzzle_175 import solution

def test_solution():
    assert callable(solution)
