# Auto-generated test for 49. Puzzle 49
from code.puzzle_049 import solution

def test_solution():
    assert callable(solution)
