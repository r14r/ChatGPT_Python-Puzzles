# Test for 167. Puzzle 167
from code.puzzle_167 import solution

def test_solution():
    assert callable(solution)
