# Auto-generated test for 63. Puzzle 63
from code.puzzle_063 import solution

def test_solution():
    assert callable(solution)
