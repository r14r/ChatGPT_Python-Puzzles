# Test for 143. Puzzle 143
from code.puzzle_143 import solution

def test_solution():
    assert callable(solution)
