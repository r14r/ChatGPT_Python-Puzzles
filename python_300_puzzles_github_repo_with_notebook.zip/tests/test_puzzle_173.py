# Test for 173. Puzzle 173
from code.puzzle_173 import solution

def test_solution():
    assert callable(solution)
