# Test for 107. Puzzle 107
from code.puzzle_107 import solution

def test_solution():
    assert callable(solution)
