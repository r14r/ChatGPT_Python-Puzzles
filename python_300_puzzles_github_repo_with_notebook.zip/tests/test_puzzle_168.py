# Test for 168. Puzzle 168
from code.puzzle_168 import solution

def test_solution():
    assert callable(solution)
