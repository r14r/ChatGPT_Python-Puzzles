# Auto-generated test for 95. Puzzle 95
from code.puzzle_095 import solution

def test_solution():
    assert callable(solution)
