# Test for 114. Puzzle 114
from code.puzzle_114 import solution

def test_solution():
    assert callable(solution)
