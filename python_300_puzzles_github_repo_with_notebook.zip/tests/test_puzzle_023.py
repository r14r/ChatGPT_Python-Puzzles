# Auto-generated test for 23. Puzzle 23
from code.puzzle_023 import solution

def test_solution():
    assert callable(solution)
