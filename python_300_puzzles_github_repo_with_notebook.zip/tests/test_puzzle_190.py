# Test for 190. Puzzle 190
from code.puzzle_190 import solution

def test_solution():
    assert callable(solution)
