# Auto-generated test for 28. Puzzle 28
from code.puzzle_028 import solution

def test_solution():
    assert callable(solution)
