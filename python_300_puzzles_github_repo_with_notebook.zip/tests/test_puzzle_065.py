# Auto-generated test for 65. Puzzle 65
from code.puzzle_065 import solution

def test_solution():
    assert callable(solution)
