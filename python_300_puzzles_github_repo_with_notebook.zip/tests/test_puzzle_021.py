# Auto-generated test for 21. Puzzle 21
from code.puzzle_021 import solution

def test_solution():
    assert callable(solution)
