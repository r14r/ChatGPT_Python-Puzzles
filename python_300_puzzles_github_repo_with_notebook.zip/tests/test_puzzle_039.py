# Auto-generated test for 39. Puzzle 39
from code.puzzle_039 import solution

def test_solution():
    assert callable(solution)
