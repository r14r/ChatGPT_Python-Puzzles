# Test for 169. Puzzle 169
from code.puzzle_169 import solution

def test_solution():
    assert callable(solution)
