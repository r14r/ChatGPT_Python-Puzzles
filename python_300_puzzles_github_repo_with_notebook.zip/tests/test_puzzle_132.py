# Test for 132. Puzzle 132
from code.puzzle_132 import solution

def test_solution():
    assert callable(solution)
