# Auto-generated test for 92. Puzzle 92
from code.puzzle_092 import solution

def test_solution():
    assert callable(solution)
