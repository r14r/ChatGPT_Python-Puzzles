# Test for 101. Puzzle 101
from code.puzzle_101 import solution

def test_solution():
    assert callable(solution)
