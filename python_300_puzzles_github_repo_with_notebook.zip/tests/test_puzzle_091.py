# Auto-generated test for 91. Puzzle 91
from code.puzzle_091 import solution

def test_solution():
    assert callable(solution)
