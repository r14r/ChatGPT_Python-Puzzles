# Auto-generated test for 71. Puzzle 71
from code.puzzle_071 import solution

def test_solution():
    assert callable(solution)
