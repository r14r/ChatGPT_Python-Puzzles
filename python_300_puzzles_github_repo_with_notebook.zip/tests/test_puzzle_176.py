# Test for 176. Puzzle 176
from code.puzzle_176 import solution

def test_solution():
    assert callable(solution)
