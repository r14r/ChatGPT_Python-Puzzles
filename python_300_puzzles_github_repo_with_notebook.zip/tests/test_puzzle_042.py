# Auto-generated test for 42. Puzzle 42
from code.puzzle_042 import solution

def test_solution():
    assert callable(solution)
