# Test for 183. Puzzle 183
from code.puzzle_183 import solution

def test_solution():
    assert callable(solution)
