# Auto-generated test for 8. Puzzle 8
from code.puzzle_008 import first_non_repeating_char

def test_first_non_repeating_char():
    assert callable(first_non_repeating_char)
