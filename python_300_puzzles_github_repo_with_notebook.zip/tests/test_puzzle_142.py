# Test for 142. Puzzle 142
from code.puzzle_142 import solution

def test_solution():
    assert callable(solution)
