# Test for 108. Puzzle 108
from code.puzzle_108 import solution

def test_solution():
    assert callable(solution)
