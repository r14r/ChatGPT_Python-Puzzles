# Test for 119. Puzzle 119
from code.puzzle_119 import solution

def test_solution():
    assert callable(solution)
