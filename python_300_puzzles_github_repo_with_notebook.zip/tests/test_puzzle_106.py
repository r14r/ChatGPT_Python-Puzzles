# Test for 106. Puzzle 106
from code.puzzle_106 import solution

def test_solution():
    assert callable(solution)
