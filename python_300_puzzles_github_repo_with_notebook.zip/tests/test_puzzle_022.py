# Auto-generated test for 22. Puzzle 22
from code.puzzle_022 import solution

def test_solution():
    assert callable(solution)
