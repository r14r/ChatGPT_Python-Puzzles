# Auto-generated test for 60. Puzzle 60
from code.puzzle_060 import solution

def test_solution():
    assert callable(solution)
