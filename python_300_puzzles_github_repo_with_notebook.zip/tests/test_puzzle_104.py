# Test for 104. Puzzle 104
from code.puzzle_104 import solution

def test_solution():
    assert callable(solution)
