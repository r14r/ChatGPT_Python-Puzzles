# Test for 130. Puzzle 130
from code.puzzle_130 import solution

def test_solution():
    assert callable(solution)
