# Auto-generated test for 79. Puzzle 79
from code.puzzle_079 import solution

def test_solution():
    assert callable(solution)
