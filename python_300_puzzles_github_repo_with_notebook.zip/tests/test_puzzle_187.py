# Test for 187. Puzzle 187
from code.puzzle_187 import solution

def test_solution():
    assert callable(solution)
