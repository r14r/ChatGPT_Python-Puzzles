# Test for 152. Puzzle 152
from code.puzzle_152 import solution

def test_solution():
    assert callable(solution)
