# Auto-generated test for 10. Puzzle 10
from code.puzzle_010 import memoize

def test_memoize():
    assert callable(memoize)
