# Auto-generated test for 47. Puzzle 47
from code.puzzle_047 import solution

def test_solution():
    assert callable(solution)
