# Test for 156. Puzzle 156
from code.puzzle_156 import solution

def test_solution():
    assert callable(solution)
