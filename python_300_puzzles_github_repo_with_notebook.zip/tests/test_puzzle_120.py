# Test for 120. Puzzle 120
from code.puzzle_120 import solution

def test_solution():
    assert callable(solution)
