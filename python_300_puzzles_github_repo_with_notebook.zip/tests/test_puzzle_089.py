# Auto-generated test for 89. Puzzle 89
from code.puzzle_089 import solution

def test_solution():
    assert callable(solution)
