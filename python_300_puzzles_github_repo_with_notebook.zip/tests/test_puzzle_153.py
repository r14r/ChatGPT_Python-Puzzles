# Test for 153. Puzzle 153
from code.puzzle_153 import solution

def test_solution():
    assert callable(solution)
