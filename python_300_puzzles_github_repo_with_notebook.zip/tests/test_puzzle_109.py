# Test for 109. Puzzle 109
from code.puzzle_109 import solution

def test_solution():
    assert callable(solution)
