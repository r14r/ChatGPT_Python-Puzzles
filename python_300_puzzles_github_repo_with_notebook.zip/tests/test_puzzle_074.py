# Auto-generated test for 74. Puzzle 74
from code.puzzle_074 import solution

def test_solution():
    assert callable(solution)
