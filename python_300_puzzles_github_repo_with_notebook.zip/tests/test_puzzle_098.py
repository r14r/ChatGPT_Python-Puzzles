# Auto-generated test for 98. Puzzle 98
from code.puzzle_098 import solution

def test_solution():
    assert callable(solution)
