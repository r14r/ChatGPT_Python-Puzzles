# Auto-generated test for 35. Puzzle 35
from code.puzzle_035 import solution

def test_solution():
    assert callable(solution)
