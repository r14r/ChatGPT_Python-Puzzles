# Test for 154. Puzzle 154
from code.puzzle_154 import solution

def test_solution():
    assert callable(solution)
