# Auto-generated test for 57. Puzzle 57
from code.puzzle_057 import solution

def test_solution():
    assert callable(solution)
