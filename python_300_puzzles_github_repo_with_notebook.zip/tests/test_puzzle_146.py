# Test for 146. Puzzle 146
from code.puzzle_146 import solution

def test_solution():
    assert callable(solution)
