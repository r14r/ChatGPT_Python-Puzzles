# Auto-generated test for 13. Puzzle 13
from code.puzzle_013 import solution

def test_solution():
    assert callable(solution)
