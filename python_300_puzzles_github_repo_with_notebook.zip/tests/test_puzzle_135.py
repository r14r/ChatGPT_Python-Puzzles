# Test for 135. Puzzle 135
from code.puzzle_135 import solution

def test_solution():
    assert callable(solution)
