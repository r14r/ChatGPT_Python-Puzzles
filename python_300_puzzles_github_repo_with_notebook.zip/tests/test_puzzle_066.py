# Auto-generated test for 66. Puzzle 66
from code.puzzle_066 import solution

def test_solution():
    assert callable(solution)
