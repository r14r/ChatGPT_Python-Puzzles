# Auto-generated test for 17. Puzzle 17
from code.puzzle_017 import solution

def test_solution():
    assert callable(solution)
