# Test for 157. Puzzle 157
from code.puzzle_157 import solution

def test_solution():
    assert callable(solution)
