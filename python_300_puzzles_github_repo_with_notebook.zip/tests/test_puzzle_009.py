# Auto-generated test for 9. Puzzle 9
from code.puzzle_009 import __init__

def test___init__():
    assert callable(__init__)
