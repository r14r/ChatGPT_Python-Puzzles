# Auto-generated test for 5. Puzzle 5
from code.puzzle_005 import __init__

def test___init__():
    assert callable(__init__)
