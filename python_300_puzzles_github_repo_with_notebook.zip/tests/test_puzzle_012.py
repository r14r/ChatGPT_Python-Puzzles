# Auto-generated test for 12. Puzzle 12
from code.puzzle_012 import solution

def test_solution():
    assert callable(solution)
