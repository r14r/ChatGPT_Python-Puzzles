# Test for 139. Puzzle 139
from code.puzzle_139 import solution

def test_solution():
    assert callable(solution)
