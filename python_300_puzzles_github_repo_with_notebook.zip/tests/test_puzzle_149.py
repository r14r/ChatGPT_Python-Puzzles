# Test for 149. Puzzle 149
from code.puzzle_149 import solution

def test_solution():
    assert callable(solution)
