# Auto-generated test for 26. Puzzle 26
from code.puzzle_026 import solution

def test_solution():
    assert callable(solution)
