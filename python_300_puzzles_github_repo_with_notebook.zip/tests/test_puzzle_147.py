# Test for 147. Puzzle 147
from code.puzzle_147 import solution

def test_solution():
    assert callable(solution)
