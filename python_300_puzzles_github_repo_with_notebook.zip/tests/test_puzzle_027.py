# Auto-generated test for 27. Puzzle 27
from code.puzzle_027 import solution

def test_solution():
    assert callable(solution)
