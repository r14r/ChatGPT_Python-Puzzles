# Test for 137. Puzzle 137
from code.puzzle_137 import solution

def test_solution():
    assert callable(solution)
