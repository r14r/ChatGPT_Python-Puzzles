# Auto-generated test for 25. Puzzle 25
from code.puzzle_025 import solution

def test_solution():
    assert callable(solution)
