# Test for 198. Puzzle 198
from code.puzzle_198 import solution

def test_solution():
    assert callable(solution)
