# Test for 196. Puzzle 196
from code.puzzle_196 import solution

def test_solution():
    assert callable(solution)
