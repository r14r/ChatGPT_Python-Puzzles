# Test for 192. Puzzle 192
from code.puzzle_192 import solution

def test_solution():
    assert callable(solution)
