# Auto-generated test for 52. Puzzle 52
from code.puzzle_052 import solution

def test_solution():
    assert callable(solution)
