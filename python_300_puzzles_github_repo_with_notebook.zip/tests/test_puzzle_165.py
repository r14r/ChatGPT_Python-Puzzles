# Test for 165. Puzzle 165
from code.puzzle_165 import solution

def test_solution():
    assert callable(solution)
