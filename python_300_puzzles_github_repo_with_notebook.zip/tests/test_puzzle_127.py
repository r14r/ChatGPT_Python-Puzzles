# Test for 127. Puzzle 127
from code.puzzle_127 import solution

def test_solution():
    assert callable(solution)
