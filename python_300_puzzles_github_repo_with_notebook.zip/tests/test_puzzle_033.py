# Auto-generated test for 33. Puzzle 33
from code.puzzle_033 import solution

def test_solution():
    assert callable(solution)
