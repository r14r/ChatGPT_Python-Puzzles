# Auto-generated test for 85. Puzzle 85
from code.puzzle_085 import solution

def test_solution():
    assert callable(solution)
