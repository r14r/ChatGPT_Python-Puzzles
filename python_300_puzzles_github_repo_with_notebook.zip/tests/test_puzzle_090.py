# Auto-generated test for 90. Puzzle 90
from code.puzzle_090 import solution

def test_solution():
    assert callable(solution)
