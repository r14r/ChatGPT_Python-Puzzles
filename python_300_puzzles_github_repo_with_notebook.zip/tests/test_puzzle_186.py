# Test for 186. Puzzle 186
from code.puzzle_186 import solution

def test_solution():
    assert callable(solution)
