# Test for 159. Puzzle 159
from code.puzzle_159 import solution

def test_solution():
    assert callable(solution)
