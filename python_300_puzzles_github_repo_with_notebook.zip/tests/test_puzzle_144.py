# Test for 144. Puzzle 144
from code.puzzle_144 import solution

def test_solution():
    assert callable(solution)
