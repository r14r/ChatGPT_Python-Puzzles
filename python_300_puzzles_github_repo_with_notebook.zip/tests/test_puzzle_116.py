# Test for 116. Puzzle 116
from code.puzzle_116 import solution

def test_solution():
    assert callable(solution)
