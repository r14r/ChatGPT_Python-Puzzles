# Test for 129. Puzzle 129
from code.puzzle_129 import solution

def test_solution():
    assert callable(solution)
