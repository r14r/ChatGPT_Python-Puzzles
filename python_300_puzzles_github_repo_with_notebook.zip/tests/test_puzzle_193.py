# Test for 193. Puzzle 193
from code.puzzle_193 import solution

def test_solution():
    assert callable(solution)
