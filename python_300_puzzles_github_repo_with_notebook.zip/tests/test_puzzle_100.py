# Auto-generated test for 100. Puzzle 100
from code.puzzle_100 import solution

def test_solution():
    assert callable(solution)
