# Test for 111. Puzzle 111
from code.puzzle_111 import solution

def test_solution():
    assert callable(solution)
