# Auto-generated test for 73. Puzzle 73
from code.puzzle_073 import solution

def test_solution():
    assert callable(solution)
