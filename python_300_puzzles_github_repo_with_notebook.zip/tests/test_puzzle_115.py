# Test for 115. Puzzle 115
from code.puzzle_115 import solution

def test_solution():
    assert callable(solution)
