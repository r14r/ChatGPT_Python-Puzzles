# Auto-generated test for 30. Puzzle 30
from code.puzzle_030 import solution

def test_solution():
    assert callable(solution)
