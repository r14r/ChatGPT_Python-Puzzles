# Auto-generated test for 2. Puzzle 2
from code.puzzle_002 import __init__

def test___init__():
    assert callable(__init__)
