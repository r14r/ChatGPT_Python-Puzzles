# Test for 162. Puzzle 162
from code.puzzle_162 import solution

def test_solution():
    assert callable(solution)
