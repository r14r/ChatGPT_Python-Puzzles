# Test for 118. Puzzle 118
from code.puzzle_118 import solution

def test_solution():
    assert callable(solution)
