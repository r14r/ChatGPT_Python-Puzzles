# Test for 178. Puzzle 178
from code.puzzle_178 import solution

def test_solution():
    assert callable(solution)
