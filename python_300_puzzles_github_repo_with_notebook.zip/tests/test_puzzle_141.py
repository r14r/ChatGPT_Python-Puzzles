# Test for 141. Puzzle 141
from code.puzzle_141 import solution

def test_solution():
    assert callable(solution)
