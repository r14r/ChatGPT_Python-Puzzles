# Test for 170. Puzzle 170
from code.puzzle_170 import solution

def test_solution():
    assert callable(solution)
