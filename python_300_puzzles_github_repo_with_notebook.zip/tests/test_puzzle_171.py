# Test for 171. Puzzle 171
from code.puzzle_171 import solution

def test_solution():
    assert callable(solution)
