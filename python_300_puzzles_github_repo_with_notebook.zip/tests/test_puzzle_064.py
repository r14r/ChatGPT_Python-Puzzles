# Auto-generated test for 64. Puzzle 64
from code.puzzle_064 import solution

def test_solution():
    assert callable(solution)
