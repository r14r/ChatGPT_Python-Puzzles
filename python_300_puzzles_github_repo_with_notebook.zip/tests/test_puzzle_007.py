# Auto-generated test for 7. Puzzle 7
from code.puzzle_007 import has_cycle

def test_has_cycle():
    assert callable(has_cycle)
