# Test for 140. Puzzle 140
from code.puzzle_140 import solution

def test_solution():
    assert callable(solution)
