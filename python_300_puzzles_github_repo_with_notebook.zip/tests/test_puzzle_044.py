# Auto-generated test for 44. Puzzle 44
from code.puzzle_044 import solution

def test_solution():
    assert callable(solution)
