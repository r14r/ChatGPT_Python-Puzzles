# Auto-generated test for 88. Puzzle 88
from code.puzzle_088 import solution

def test_solution():
    assert callable(solution)
