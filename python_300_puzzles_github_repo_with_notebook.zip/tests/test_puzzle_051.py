# Auto-generated test for 51. Puzzle 51
from code.puzzle_051 import solution

def test_solution():
    assert callable(solution)
