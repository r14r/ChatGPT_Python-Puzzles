# Test for 191. Puzzle 191
from code.puzzle_191 import solution

def test_solution():
    assert callable(solution)
