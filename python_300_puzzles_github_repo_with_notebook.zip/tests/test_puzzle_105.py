# Test for 105. Puzzle 105
from code.puzzle_105 import solution

def test_solution():
    assert callable(solution)
