# Test for 194. Puzzle 194
from code.puzzle_194 import solution

def test_solution():
    assert callable(solution)
