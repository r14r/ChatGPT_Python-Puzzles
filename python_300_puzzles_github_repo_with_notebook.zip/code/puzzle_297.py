# 297. Puzzle 297
# Solution for: 297. Puzzle 297
def solution():
    # TODO: implement
    pass
