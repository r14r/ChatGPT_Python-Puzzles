# 125. Puzzle 125
# Solution for: 125. Puzzle 125
def solution():
    # TODO: implement
    pass
