# 144. Puzzle 144
# Solution for: 144. Puzzle 144
def solution():
    # TODO: implement
    pass
