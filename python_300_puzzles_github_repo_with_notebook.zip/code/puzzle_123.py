# 123. Puzzle 123
# Solution for: 123. Puzzle 123
def solution():
    # TODO: implement
    pass
