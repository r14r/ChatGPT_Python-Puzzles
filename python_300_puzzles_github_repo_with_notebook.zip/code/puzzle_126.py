# 126. Puzzle 126
# Solution for: 126. Puzzle 126
def solution():
    # TODO: implement
    pass
