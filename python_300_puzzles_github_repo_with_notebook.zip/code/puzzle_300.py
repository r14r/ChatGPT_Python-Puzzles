# 300. Puzzle 300
# Solution for: 300. Puzzle 300
def solution():
    # TODO: implement
    pass
