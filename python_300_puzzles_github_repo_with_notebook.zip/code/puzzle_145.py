# 145. Puzzle 145
# Solution for: 145. Puzzle 145
def solution():
    # TODO: implement
    pass
