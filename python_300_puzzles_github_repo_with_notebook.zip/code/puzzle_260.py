# 260. Puzzle 260
# Solution for: 260. Puzzle 260
def solution():
    # TODO: implement
    pass
