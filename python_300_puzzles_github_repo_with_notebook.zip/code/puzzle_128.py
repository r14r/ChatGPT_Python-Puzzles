# 128. Puzzle 128
# Solution for: 128. Puzzle 128
def solution():
    # TODO: implement
    pass
