# 296. Puzzle 296
# Solution for: 296. Puzzle 296
def solution():
    # TODO: implement
    pass
