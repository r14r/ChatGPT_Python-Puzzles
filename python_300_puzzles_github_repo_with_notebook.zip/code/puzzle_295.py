# 295. Puzzle 295
# Solution for: 295. Puzzle 295
def solution():
    # TODO: implement
    pass
