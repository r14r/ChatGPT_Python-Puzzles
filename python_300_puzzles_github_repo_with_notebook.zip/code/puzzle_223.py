# 223. Puzzle 223
# Solution for: 223. Puzzle 223
def solution():
    # TODO: implement
    pass
