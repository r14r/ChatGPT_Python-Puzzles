# 2. Puzzle 2
class Stack:
    def __init__(self):
        self.stack = []

    def push(self, val):
        self.stack.append(val)

    def pop(self):
        return self.stack.pop() if self.stack else None

    def is_empty(self):
        return not self.stack