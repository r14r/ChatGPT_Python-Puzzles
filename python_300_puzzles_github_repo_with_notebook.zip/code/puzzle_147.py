# 147. Puzzle 147
# Solution for: 147. Puzzle 147
def solution():
    # TODO: implement
    pass
