# 273. Puzzle 273
# Solution for: 273. Puzzle 273
def solution():
    # TODO: implement
    pass
