# 124. Puzzle 124
# Solution for: 124. Puzzle 124
def solution():
    # TODO: implement
    pass
