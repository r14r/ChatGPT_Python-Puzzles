# 200. Puzzle 200
# Solution for: 200. Puzzle 200
def solution():
    # TODO: implement
    pass
