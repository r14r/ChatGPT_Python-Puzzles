# 214. Puzzle 214
# Solution for: 214. Puzzle 214
def solution():
    # TODO: implement
    pass
