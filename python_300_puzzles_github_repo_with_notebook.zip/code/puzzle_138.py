# 138. Puzzle 138
# Solution for: 138. Puzzle 138
def solution():
    # TODO: implement
    pass
