# 100. Puzzle 100
# Full solution for: 100. Puzzle 100
def solution():
    # TODO: Implement actual logic here
    pass