# 150. Puzzle 150
# Solution for: 150. Puzzle 150
def solution():
    # TODO: implement
    pass
