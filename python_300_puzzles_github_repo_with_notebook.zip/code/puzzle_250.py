# 250. Puzzle 250
# Solution for: 250. Puzzle 250
def solution():
    # TODO: implement
    pass
