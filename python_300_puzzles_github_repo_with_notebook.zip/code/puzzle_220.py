# 220. Puzzle 220
# Solution for: 220. Puzzle 220
def solution():
    # TODO: implement
    pass
