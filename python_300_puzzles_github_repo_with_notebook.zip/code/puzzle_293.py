# 293. Puzzle 293
# Solution for: 293. Puzzle 293
def solution():
    # TODO: implement
    pass
