# 173. Puzzle 173
# Solution for: 173. Puzzle 173
def solution():
    # TODO: implement
    pass
