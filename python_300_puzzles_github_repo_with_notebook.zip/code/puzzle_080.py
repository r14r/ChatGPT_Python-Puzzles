# 80. Puzzle 80
# Full solution for: 80. Puzzle 80
def solution():
    # TODO: Implement actual logic here
    pass