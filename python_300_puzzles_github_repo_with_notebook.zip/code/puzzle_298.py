# 298. Puzzle 298
# Solution for: 298. Puzzle 298
def solution():
    # TODO: implement
    pass
