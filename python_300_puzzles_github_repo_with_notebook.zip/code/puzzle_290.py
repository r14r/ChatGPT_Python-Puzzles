# 290. Puzzle 290
# Solution for: 290. Puzzle 290
def solution():
    # TODO: implement
    pass
