# 265. Puzzle 265
# Solution for: 265. Puzzle 265
def solution():
    # TODO: implement
    pass
