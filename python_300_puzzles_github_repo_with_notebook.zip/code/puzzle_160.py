# 160. Puzzle 160
# Solution for: 160. Puzzle 160
def solution():
    # TODO: implement
    pass
