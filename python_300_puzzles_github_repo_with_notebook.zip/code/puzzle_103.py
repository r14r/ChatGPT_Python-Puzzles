# 103. Puzzle 103
# Solution for: 103. Puzzle 103
def solution():
    # TODO: implement
    pass
