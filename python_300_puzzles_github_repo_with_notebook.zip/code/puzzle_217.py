# 217. Puzzle 217
# Solution for: 217. Puzzle 217
def solution():
    # TODO: implement
    pass
