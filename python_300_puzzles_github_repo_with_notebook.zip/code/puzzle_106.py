# 106. Puzzle 106
# Solution for: 106. Puzzle 106
def solution():
    # TODO: implement
    pass
