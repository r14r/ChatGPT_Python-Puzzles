# 121. Puzzle 121
# Solution for: 121. Puzzle 121
def solution():
    # TODO: implement
    pass
