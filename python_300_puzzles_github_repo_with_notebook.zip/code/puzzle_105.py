# 105. Puzzle 105
# Solution for: 105. Puzzle 105
def solution():
    # TODO: implement
    pass
