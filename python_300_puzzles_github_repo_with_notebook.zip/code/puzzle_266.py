# 266. Puzzle 266
# Solution for: 266. Puzzle 266
def solution():
    # TODO: implement
    pass
