# 110. Puzzle 110
# Solution for: 110. Puzzle 110
def solution():
    # TODO: implement
    pass
