# 9. Puzzle 9
import json

class TreeNode:
    def __init__(self, val):
        self.val = val
        self.left = self.right = None

def serialize(root):
    if not root:
        return None
    return json.dumps({
        'val': root.val,
        'left': serialize(root.left),
        'right': serialize(root.right)
    })

def deserialize(data):
    if data is None:
        return None
    obj = json.loads(data)
    node = TreeNode(obj['val'])
    node.left = deserialize(obj['left'])
    node.right = deserialize(obj['right'])
    return node