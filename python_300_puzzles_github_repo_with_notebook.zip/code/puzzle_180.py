# 180. Puzzle 180
# Solution for: 180. Puzzle 180
def solution():
    # TODO: implement
    pass
