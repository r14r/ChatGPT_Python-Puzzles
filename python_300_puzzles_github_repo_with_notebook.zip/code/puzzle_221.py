# 221. Puzzle 221
# Solution for: 221. Puzzle 221
def solution():
    # TODO: implement
    pass
