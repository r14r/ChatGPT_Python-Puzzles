# 299. Puzzle 299
# Solution for: 299. Puzzle 299
def solution():
    # TODO: implement
    pass
