# 104. Puzzle 104
# Solution for: 104. Puzzle 104
def solution():
    # TODO: implement
    pass
