# 182. Puzzle 182
# Solution for: 182. Puzzle 182
def solution():
    # TODO: implement
    pass
