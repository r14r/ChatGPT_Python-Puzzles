# 120. Puzzle 120
# Solution for: 120. Puzzle 120
def solution():
    # TODO: implement
    pass
