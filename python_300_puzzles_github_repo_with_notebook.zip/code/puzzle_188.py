# 188. Puzzle 188
# Solution for: 188. Puzzle 188
def solution():
    # TODO: implement
    pass
