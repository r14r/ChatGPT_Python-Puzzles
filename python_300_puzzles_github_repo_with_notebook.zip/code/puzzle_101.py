# 101. Puzzle 101
# Solution for: 101. Puzzle 101
def solution():
    # TODO: implement
    pass
