# 294. Puzzle 294
# Solution for: 294. Puzzle 294
def solution():
    # TODO: implement
    pass
